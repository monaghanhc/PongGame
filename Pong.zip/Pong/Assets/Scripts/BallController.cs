﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallController : MonoBehaviour
{
    public float speed;

    float directionY;
    Vector3 direction;

    // Start is called before the first frame update
    void Start()
    {
        // Generate a random direction vector
        directionY = Random.Range(-1f, 1f);
        direction = new Vector3(-1, directionY);
        direction = direction.normalized;
        //float angle = Random.Range(3f * Mathf.PI / 4f, 5f * Mathf.PI / 4f);
        //direction = new Vector3(Mathf.Cos(angle), Mathf.Sin(angle));
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += speed * direction;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("OnTriggerEnter2D Called!");

        // If Colliding with ScoreZone
        if (other.CompareTag("ScoreZone"))
        {
            // Do Score stuff
            Debug.Log("BALL HIT SCORE ZONE");
        }
        // Else If colliding with BounceWall
        else if (other.CompareTag("BounceWall"))
        {
            // Do Bounce stuff
            direction = new Vector3(direction.x, -direction.y);
        }
        // Else if colliding with Paddle
        // Do paddle bounce



        //Vector3 newDirection = Vector3.Reflect(direction, Vector3.up);
        //direction = newDirection.normalized;
    }
}
