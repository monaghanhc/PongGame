﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Score : MonoBehaviour
{
   // public Text leftScore;
    //public Text rightScore;
    //int score = 0;

    // Start is called before the first frame update
    void Start()
    {
      //  leftScore.text = "" + score;
       // rightScore.text = "" + score;
    }

    // Update is called once per frame
    void Update()
    {
       
        
    }
    //private void OnTriggerEnter2D(Collider2D Base)
}
